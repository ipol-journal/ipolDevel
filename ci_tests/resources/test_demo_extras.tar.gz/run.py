#!/usr/bin/python

import os

algo_info = {}
os.system('convert input_0.png input_0.pgm')
os.system('lsd -P output.eps -S output.svg input_0.pgm output.txt')

#--- convert the EPS result into a PNG image
os.system('gs -dNOPAUSE -dBATCH -sDEVICE=pnggray -dGraphicsAlphaBits=4 -r72 -dEPSCrop -sOutputFile=output.png output.eps')
os.system('convert -negate output.png output-inv.png')

#--- save the number of detections
num_lines = sum(1 for line in open('output.txt'))
algo_info['num_detections'] = num_lines

#--- save the binary version
os.system('lsd --version >version.txt')

version_file = open('version.txt', 'r')
version_info = version_file.readline()
version_file.close()
algo_info['version'] = version_info

file = open('algo_info.txt','w') 
file.write('version=%s' % version_info)
file.write('num_detections=%d' % num_lines)
file.close() 